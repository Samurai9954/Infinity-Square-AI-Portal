import stocker
import sys
print(stocker.predict.tomorrow(sys.argv[1]))
